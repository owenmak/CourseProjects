typedef union Data {
	double db;
	char * str;
} data;

typedef struct Info {
	data *value;
	char *colName;
	char *conditional;
	char valueType;
} info;
#include "defs_itf.h"
#include <stdlib.h>
