#include"defs_itf.h"

Table* rf1(Table *tbl) {
	Row ** rows = tbl_rows(tbl);
	Table *t = tbl_make();
	char *type = tbl_type(tbl);
	int r;
	int rowCount = tbl_row_count(tbl);
	int columnCount = tbl_column_count(tbl)
	for(int i = 0; i < rowCount; i++) {
		r = rand() % (rowCount - 1);
		tbl_start_row(t, columnCount);
		for(int j = 0; j < columnCount; j++) {
			if(type[j] == 'S') {
				tbl_add_string_to_row(t, tbl_string_at(rows[i], j));
			}
			else {
				tbl_add_double_to_row(t, tbl_double_at(rows[i], j));
			}
		}
	}
	return t;
}

Table* rf2(Table *tbl) {
	Table *t = tbl_make();
	int columnCount = tbl_column_count(tbl);
	int rowCount = tbl_row_count(tbl);
	int loopCount = columnCount * 2 / 3;
	char *type = tbl_type(tbl);
	int *randomColumns = (int*)malloc(sizeof(int) * loopCount);
	int r;
	for(int i = 0 ; i < loopCount; i++) {
		int flag = 1;
		while(flag) {
			r = rand() % (columnCount - 1);
			if(i == 0) {
				flag = 0;
				break;
			}
			for(int j = 0; j < i; j++) {
				if(randomColumns[j] == r) {
					break;
				}
				if(j == i - 1) {
					flag = 0;
				}
			}
		}
		randomColumns[i] = rand() % (columnCount - 1);
	}
	for(int i = 0 ; i < rowCount; i++) {
		tbl_start_row(t, loopCount);
		for(int j = 0; j < loopCount; j++) {
			if(type[randomColumns[j]] == 'S') {
				tbl_add_string_to_row(t, tbl_string_at(tbl_row_at(tbl, i), randomColumns[j]));
			}
			else {
				tbl_add_double_to_row(t, tbl_double_at(tbl_row_at(tbl, i), randomColumns[j]));
			}
		}
	}
	return t;
}
