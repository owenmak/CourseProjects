public class IllegalAnimalException extends Exception {
    public IllegalAnimalException(String message) {
    	super(message);
    }
}
