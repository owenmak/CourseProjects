/**
 * Defines the valid types for the sites.
 * 
 * @author adaskin
 * 
 */
public enum SiteType {
    FEEDING, WINTERING, NESTING
}
