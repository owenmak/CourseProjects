
/*
 * CS252: Shell project
 *
 * Template file.
 * You will need to add more code here to execute the command table.
 *
 * NOTE: You are responsible for fixing any bugs this code may have!
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include "command.h"
#include <regex.h>
#include <pwd.h>
extern char ** environ;

SimpleCommand::SimpleCommand()
{
	// Creat available space for 5 arguments
	_append = 0;
	_numberOfAvailableArguments = 5;
	_numberOfArguments = 0;
	_arguments = (char **) malloc( _numberOfAvailableArguments * sizeof( char * ) );
}

void
SimpleCommand::insertArgument( char * argument )
{
	if(argument[0] == '~') {
		if(argument[1] == NULL) {
			argument = strdup(getenv("HOME"));
		}
		else if( argument[1] == '/') {
			argument = strcat(strdup(getenv("HOME")),argument+1);
		}
		else {
			char *direc;
			char *ind = strchr(argument, '/');
			if(ind != NULL) {
				char *lgname = (char*)malloc( sizeof(char) * (ind - argument));
				for(int i = 0; i < ind-argument-1; i++) {
					lgname[i] = argument[i+1];
				}
				lgname[ind-argument-1] = '\0';
				direc = getpwnam(lgname)->pw_dir;
				free(lgname);
				argument = strcat(direc, ind);
			}
			else {
				direc = getpwnam(argument+1)->pw_dir;
				argument = strdup(direc);
			}
		}
	}

	char * arg = argument;
	char * buffer = "^.*${[^}][^}]*}.*$";
	regex_t re;
	regmatch_t match;
	int  result = regcomp(&re,buffer, NULL);
	if(result == 0) {
		arg = strdup(argument);
		while(!regexec(&re, arg, 1, &match, 0)) {
			int startInd = 0;
			int endInd = 0;
			for(int i = 0; i < strlen(arg); i++) {
				if(arg[i] == '{')
					startInd = i;
				if(arg[i] == '}')
					endInd = i;
			}
			char *var = (char*)malloc(sizeof(char) * (endInd - startInd));
			for(int i = 0; i < endInd - startInd - 1; i++) {
				var[i] = arg[i+startInd+1];
			}
			var[endInd-startInd-1] = '\0';
/*			printf("var:%s\n",var);
			printf("env:%s\n",getenv(var));*/
			char *a = (char*)malloc(2*sizeof(char) * strlen(arg)+100);
			int count = 0;
			for(int i = 0; i < startInd - 1; i++) {
				a[count] = arg[i];
				count++;
			}
			for(int i = 0; i < strlen(getenv(var)); i++) {
				a[count] = getenv(var)[i];
				count++;
			}
			for(int i = endInd + 1; i < strlen(arg); i++) {
				a[count] = arg[i];
				count++;
			}
			a[count] = '\0';
/*			strncpy(a, arg, startInd);
//			printf("first part:%s\n",a);
			strcat(a, strdup(getenv(var)));
//			printf("second part:%s\n", a);
			strcat(a, arg+endInd+1);*/
//			printf("third part:%s\n", a);
			free(arg);
			free(var);
			arg = a;
		}
	}

/*	printf("inserting argument: %s\n",arg);*/
	if ( _numberOfAvailableArguments == _numberOfArguments  + 1 ) {
		// Double the available space
		_numberOfAvailableArguments *= 2;
		_arguments = (char **) realloc( _arguments,
				  _numberOfAvailableArguments * sizeof( char * ) );
	}
	
	_arguments[ _numberOfArguments ] = arg;

	// Add NULL argument at the end
	_arguments[ _numberOfArguments + 1] = NULL;
	
	_numberOfArguments++;
}

Command::Command()
{
	// Create available space for one simple command
	_numberOfAvailableSimpleCommands = 1;
	_simpleCommands = (SimpleCommand **)
		malloc( _numberOfSimpleCommands * sizeof( SimpleCommand * ) );

	_numberOfSimpleCommands = 0;
	_outFile = 0;
	_inputFile = 0;
	_errFile = 0;
	_background = 0;
//	_append = 0;
}

void
Command::insertSimpleCommand( SimpleCommand * simpleCommand )
{
	if ( _numberOfAvailableSimpleCommands == _numberOfSimpleCommands ) {
		_numberOfAvailableSimpleCommands *= 2;
		_simpleCommands = (SimpleCommand **) realloc( _simpleCommands,
			 _numberOfAvailableSimpleCommands * sizeof( SimpleCommand * ) );
	}
	
	_simpleCommands[ _numberOfSimpleCommands ] = simpleCommand;
	_numberOfSimpleCommands++;
}

void
Command:: clear()
{
	for ( int i = 0; i < _numberOfSimpleCommands; i++ ) {
		for ( int j = 0; j < _simpleCommands[ i ]->_numberOfArguments; j ++ ) {
//			printf("%d, %d\n", i, j);
			free ( _simpleCommands[ i ]->_arguments[ j ] );
		}
		
		free ( _simpleCommands[ i ]->_arguments );
		free ( _simpleCommands[ i ] );
	}

	if ( _outFile ) {
		free( _outFile );
	}

	if ( _inputFile ) {
		free( _inputFile );
	}

	if ( _errFile ) {
		free( _errFile );
	}

	_numberOfSimpleCommands = 0;
	_outFile = 0;
	_inputFile = 0;
	_errFile = 0;
	_background = 0;
}

void
Command::print()
{
	printf("\n\n");
	printf("              COMMAND TABLE                \n");
	printf("\n");
	printf("  #   Simple Commands\n");
	printf("  --- ----------------------------------------------------------\n");
	
	for ( int i = 0; i < _numberOfSimpleCommands; i++ ) {
		printf("  %-3d ", i );
		for ( int j = 0; j < _simpleCommands[i]->_numberOfArguments; j++ ) {
			printf("\"%s\" \t", _simpleCommands[i]->_arguments[ j ] );
		}
	}

	printf( "\n\n" );
	printf( "  Output       Input        Error        Background\n" );
	printf( "  ------------ ------------ ------------ ------------\n" );
	printf( "  %-12s %-12s %-12s %-12s\n", _outFile?_outFile:"default",
		_inputFile?_inputFile:"default", _errFile?_errFile:"default",
		_background?"YES":"NO");
	printf( "\n\n" );
	
}


void
Command::execute()
{
	// Don't do anything if there are no simple commands
	if ( _numberOfSimpleCommands == 0 ) {
		prompt();
		return;
	}

	// Print contents of Command data structure
//	print();

	
	int defaultin = dup(0);
	int defaultout = dup(1);
	int defaulterr = dup(2);

	int infd;
	int outfd;
//	int errfd;
	if(_inputFile != NULL) {
		infd = open(_inputFile, O_RDONLY);
		if(infd < 0) {
			perror("create infile");
			exit(2);
		}
	}
	else
		infd = dup(defaultin);

	if(_errFile != NULL) {
		int errfd = open(_errFile, O_WRONLY|O_CREAT|O_APPEND, 0666);
		if(errfd < 0) {
			perror("create error file");
			exit(2);
		}
		dup2(errfd, 2);
		close(errfd);
	}

	
	int ret;
	for (int i = 0; i < _numberOfSimpleCommands; i++) {
		dup2(infd, 0);
		close(infd);
		if(i == _numberOfSimpleCommands-1) {
			if(_outFile!= NULL) {
//				printf("append : %d\n",_append);
				if(_simpleCommands[i]->_append)
					outfd = open(_outFile, O_WRONLY|O_CREAT|O_APPEND,0666);
				else
					outfd = creat(_outFile, 0666);
				if(outfd < 0) {
					perror("create outfile");
					exit(2);
				}
			}
			else
				outfd = dup(defaultout);
		}
		else {
			int fdpipe[2];
			if(pipe(fdpipe) == -1) {
				perror("creating pipe");
				exit(2);
			}
			outfd = fdpipe[1];
			infd = fdpipe[0];
		}
		dup2(outfd, 1);
		close(outfd);

		if(!strcmp(_simpleCommands[i]->_arguments[0], "exit")) {
			printf("  Good bye!!\n");
			exit(0);
		}


		if(!strcmp(_simpleCommands[i]->_arguments[0], "cd")) {
			char path[256];
			int suc;
			if(_simpleCommands[i]->_arguments[1] == NULL) {
//				path[0] = '/';
//				path[1] = '\0';
				chdir(getenv("HOME"));
				clear();
				prompt();
				return;
			}
			else if(_simpleCommands[i]->_arguments[1][0] != '/') {
				
				getcwd(path, sizeof(path));
				strcat(path, "/");

				strcat(path, _simpleCommands[i]->_arguments[1]);
//					printf("path: %s\n", path);
				suc = chdir(path);
			}
			else {
				suc = chdir(_simpleCommands[i]->_arguments[1]);
			}
			if(suc != 0) {
				printf("No such file or directory\n");
			}
			clear();
			prompt();
			return;
		}
		if(!strcmp(_simpleCommands[i]->_arguments[0], "setenv")) {
			char *e = strdup(_simpleCommands[i]->_arguments[1]);
			strcat(e,"=");
			strcat(e, _simpleCommands[i]->_arguments[2]);
			putenv(e);
			clear();
			prompt();
			return;
		}
		if(!strcmp(_simpleCommands[i]->_arguments[0], "unsetenv")) {
			char **p = environ;
			while(*p!=NULL) {
				if(strstr(*p, _simpleCommands[i]->_arguments[1])!=NULL) {
//					printf("Found\n");
					break;
				}
				p++;
			}
			char **e = p;
			e++;
			free(*p);
			while(*p!=NULL) {
				*p = *e;
				p++;
				e++;
			}
			clear();
			prompt();
			return;
		}


		ret = fork();
		if(ret == 0) {
			// child
//			close(fdpipe[0]);
//			close(fdpipe[1]);
//			close(defaultin);
//			close(defaultout);
//			close(defaulterr);
			execvp(_simpleCommands[i]->_arguments[0], _simpleCommands[i]->_arguments);
			perror("execvp");
			exit(0);
		}
		else if( ret < 0) {
			perror("fork");
			return;
		}
	// Parent shell continue
		if (!_background) {
			waitpid(ret, 0, 0);
		}
	}
	dup2(defaultin, 0);
	dup2(defaultout, 1);
	close(defaultin);
	close(defaultout);

	// Clear to prepare for next command
	clear();
	
	// Print new prompt
	prompt();
}

// Shell implementation

void
Command::prompt()
{	
	if(isatty(0)) {
		printf("myshell>");
		fflush(stdout);
	}
}

Command Command::_currentCommand;
SimpleCommand * Command::_currentSimpleCommand;

int yyparse(void);

extern "C" void disp(int sig) {
	fprintf(stderr,"\n");
	Command::_currentCommand.prompt();
}

void killzombie(int signum) {
	while(waitpid(-1, NULL, WNOHANG) > 0);
}


main()
{
	struct sigaction signalAction;
	signalAction.sa_handler = killzombie;
	sigemptyset(&signalAction.sa_mask);
	signalAction.sa_flags = SA_RESTART;

	int error = sigaction(SIGCHLD, &signalAction, NULL);
	if(error)
	{
		perror("sigaction");
		exit(-1);
	}
	signal(SIGINT, disp);

	Command::_currentCommand.prompt();
	yyparse();
}

