#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <signal.h>
#include <pthread.h>
#include <dirent.h>
#include <ctime>
#include <vector>
#include <iostream>
#include <algorithm>
#include <dlfcn.h>

using namespace std;

struct files {
	char *file_name; // name of the file
	time_t modify_time;
	char *file_dirc; // the directory of the file
	bool isDirectory;
};

bool nameSortAscend(const files &a, const files &b) {
	return (strcmp(a.file_name, b.file_name) > 0);
};

bool nameSortDescend(const files &a, const files &b) {
	return (strcmp(a.file_name, b.file_name) < 0);
};


bool timeSortAscend(const files &a, const files &b) {
	return (difftime(a.modify_time, b.modify_time) > 0);
}

bool timeSortDescend(const files &a, const files &b) {
	return (difftime(a.modify_time, b.modify_time) < 0);
}

int QueueLength = 5;

char *loaded_mod[128]; // at most store 128 mods

int mod_count = 0;

int request_count = 0; // number of requests.

time_t server_Start;

double min_time = 100000;

double max_time = -1;

time_t start_time;

time_t end_time;

pthread_mutex_t mutex;

const char* pro_err = "HTTP/1.0 404 File Not Found\r\nServer: cs252_zmai\r\nContent-type: text/plain\r\n\r\n404_Not_Found";

const char* protocol = "HTTP/1.0 200 Document follows\r\nServer: cs252_zmai\r\nContent-type:";

const char* cgi_prot = "HTTP/1.0 200 Document follows\r\nServer: cs252_zmai\r\n";

const char* html_source1 = "<html>\n <head>\n   <title>Index of /homes/cs252/lab5-http-server/lab5-src</title>\n    </head>\n	 <body>\n	 <h1>Index of";
// /homes/cs252/lab5-http-server/lab5-src
const char* html_source2 = "</h1>\n	 <table><tr><th><img src=\"/icons/blank.xbm\" alt=\"[ICO]\"></th><th><a href=\"?C=N;O=";
const char* html_source3 = "\">Name</a></th><th><a href=\"?C=M;O=";
const char* html_source4 = "\">Last modified</a></th><th>\n"; 


//<a href=\"?C=S;O=A\">Size</a></th><th><a href=\"?C=D;O=A\">Description</a></th></tr><tr><th colspan=\"5\"><hr></th></tr>\n";//	 <tr><td valign=\"top\"><img src=\"/icons/back.gif\" alt=\"[DIR]\"></td><td><a href=\"/homes/cs252/lab5-http-server/\">Parent Directory</a>       </td><td>&nbsp;</td><td align=\"right\">  - </td><td>&nbsp;</td></tr>";


const char* html_source5 ="\n<tr><th colspan=\"5\"><hr></th></tr> </table>	 <address>Apache/2.2.24 (Unix) mod_ssl/2.2.24 OpenSSL/0.9.8r Server at www.cs.purdue.edu Port </address>	 </body></html>";

// Processes time request
void processTimeRequest( int socket );

void processRequest( int socket);

bool endsWith(char * str1, char * str2) { //str1 is soruce, str2 is the end
	if(strlen(str1) < strlen(str2))
		return false;
	for(int i = 1; i <= strlen(str2); i++) {
		if(str1[strlen(str1)-i] != str2[strlen(str2)-i])
			return false;
	}
	return true;
}

void killzombie(int signum) {
	while(waitpid(-1, NULL, WNOHANG) > 0);
}

void processRequestThread(int socket) {
	processRequest(socket); 
	close(socket);
}


void thread_server(int masterSocket) { // thread	
		
		pthread_t tid;

		while(1) {
		    struct sockaddr_in clientIPAddress;
   		 	int alen = sizeof( clientIPAddress );
			int slaveSocket = accept( masterSocket, (struct sockaddr *)&clientIPAddress, (socklen_t*)&alen);

			pthread_attr_t attr;
			pthread_attr_init(&attr);
			pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

			pthread_create(&tid, &attr,(void*(*)(void *))processRequestThread, (void *)slaveSocket);
		}
}

void fork_server(int masterSocket) { // fork
	while(1) {
	    struct sockaddr_in clientIPAddress;
    	int alen = sizeof( clientIPAddress );
		int slaveSocket = accept( masterSocket, (struct sockaddr *)&clientIPAddress, (socklen_t*)&alen);		
		if(slaveSocket < 0) {
			perror("accept");
			exit(-1);
		}
		
		int ret = fork();
		if(ret == 0) {
			processRequest( slaveSocket); 
			close(slaveSocket);
			exit(EXIT_SUCCESS);
		}
		close(slaveSocket);
//		close(masterSocket);
	}
}
	
	// pool thread


void *poolSlave(int masterSocket) {
	while(1) {
	    struct sockaddr_in clientIPAddress;
    	int alen = sizeof( clientIPAddress );
		pthread_mutex_lock(&mutex);
		int slaveSocket = accept( masterSocket,
								(struct sockaddr *)&clientIPAddress,
								(socklen_t*)&alen);
		pthread_mutex_unlock(&mutex);
		
		if ( slaveSocket < 0 ) {
			perror( "accept" );
			exit( -1 );
    	}
		processRequest( slaveSocket); 
	}
}


void pool_server(int masterSocket) {
	pthread_attr_t attr;
	pthread_t tid[5];
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	pthread_mutex_init( &mutex, NULL);
	for(int i = 0; i < 4; i++) {
		pthread_create(&tid[i], NULL, (void *(*)(void *))poolSlave, (void *)masterSocket);
	}
	poolSlave(masterSocket);
}

void stats_page(int fd) {
};


void log_page(int fd) {
	write(fd, protocol, strlen(protocol));
	write(fd, "text/plain\r\n\r\n", strlen("text/plain\r\n\r\n"));
	char buff[1000];
	time_t currTime;
	time(&currTime);
	time(&end_time);
	if(difftime(end_time, start_time) > max_time)
		max_time = difftime(end_time, start_time);
	if(difftime(end_time, start_time) < min_time)
		min_time = difftime(end_time, start_time);
	sprintf(buff, "Author of this http-server: Zilun Mai\nTime of requests received: %d\nThe server has been up %.fs\nMax time on a request is: %.fs\nMin time on a request is:%.fs\n", request_count, difftime(currTime, server_Start), max_time, min_time);
//	write(fd, "Author of this http-server: Zilun Mai\n", strlen("Author of this http-server: Zilun Mai\n"));
	write(fd, buff, strlen(buff));


}

int
main( int argc, char ** argv )
{
  // Print usage if not enough arguments
/*  if ( argc < 2 ) {
    fprintf( stderr, "%s", usage );
    exit( -1 );
  }*/
  struct sigaction signalAction;
  signalAction.sa_handler = killzombie;
  sigemptyset(&signalAction.sa_mask);
  signalAction.sa_flags = SA_RESTART;

  int sigact = sigaction(SIGCHLD, &signalAction, NULL);
  if(sigact) {
  	perror("sigaction");
	exit(-1);
  }
// flag:0-default  1-fork 2-thread, 3-pool
  int flag = 0;
  if(argv[1]!=NULL && argv[1][1] == 'f')
  	flag = 1;
  else if (argv[1]!=NULL && argv[1][1] == 't')
  	flag = 2;
  else if (argv[1]!=NULL && argv[1][1] == 'p')
    flag = 3;
  // Get the port from the arguments

  int port = 1234; // set to initail 1234
  if(flag == 0 && argc == 2) 
  	port =  atoi( argv[1] );
  else if(flag != 0 && argc == 3)
  	port = atoi( argv[2]);

	printf("flag: %d, port: %d\n", flag, port);
  
  // Set the IP address and port for this server
  struct sockaddr_in serverIPAddress; 
  memset( &serverIPAddress, 0, sizeof(serverIPAddress) );
  serverIPAddress.sin_family = AF_INET;
  serverIPAddress.sin_addr.s_addr = INADDR_ANY;
  serverIPAddress.sin_port = htons((u_short) port);
  // Allocate a socket
  int masterSocket =  socket(PF_INET, SOCK_STREAM, 0);
  if ( masterSocket < 0) {
    perror("socket");
    exit( -1 );
  }

  time(&server_Start);

  // Set socket options to reuse port. Otherwise we will
  // have to wait about 2 minutes before reusing the sae port number
  int optval = 1; 
  int err = setsockopt(masterSocket, SOL_SOCKET, SO_REUSEADDR, 
		       (char *) &optval, sizeof( int ) );
   
  // Bind the socket to the IP address and port
  int error = bind( masterSocket,
		    (struct sockaddr *)&serverIPAddress,
		    sizeof(serverIPAddress) );
  if ( error ) {
    perror("bind");
    exit( -1 );
  }
  
  // Put socket in listening mode and set the 
  // size of the queue of unprocessed connections
  error = listen( masterSocket, QueueLength);
  if ( error ) {
    perror("listen");
    exit( -1 );
  }

  if(flag == 1)
  	fork_server(masterSocket);
  else if(flag == 2)
  	thread_server(masterSocket);
  else if(flag == 3)
  	pool_server(masterSocket);
  else { //iterative
	  while ( 1 ) {

    // Accept incoming connections
	    struct sockaddr_in clientIPAddress;
    	int alen = sizeof( clientIPAddress );
	    int slaveSocket = accept( masterSocket,
				      (struct sockaddr *)&clientIPAddress,
				      (socklen_t*)&alen);
		
		//if(slaveSocket == -1 && errno == EINTR && flag == 1)
//			continue; 
	    if ( slaveSocket < 0 ) {
    	  perror( "accept" );
	      exit( -1 );
	    }
		processRequest(slaveSocket);
		close(slaveSocket);
	  }
//	  close(slaveSocket);
	}
}


void
processRequest(int fd) {
	request_count++;
	time(&start_time);

	const int MaxLength = 1024;
	char doc_path[MaxLength + 1];
	int length = 0;
	int n ;
	unsigned char newChar;

	unsigned char lastChar = 0;

	unsigned l2Char = 0;

	unsigned l3Char = 0;
	
	int gotGet = 0;
	int clrf = 0;
	while(length < MaxLength &&
		( n = read( fd, &newChar, sizeof(newChar))) > 0 ) {
//			printf("%c",newChar);
			// gotGet status: 0 no get yet, 1 in get, -1 ignore
			if (newChar == '\n' && lastChar == '\r'  && l2Char == '\n' &&l3Char == '\r') {
				break;
			}
			if(gotGet == 1) 
				doc_path[length++] = newChar;

			if(newChar == ' ') {
				if(gotGet == 0)
					gotGet = 1;
				else if(gotGet == 1) {
					gotGet = -1;
					doc_path[--length] = '\0';
				}
			
			}
			l3Char = l2Char;
			l2Char = lastChar;
			lastChar = newChar;

			
		}

		if(endsWith(doc_path, "log") || endsWith(doc_path, "log/")) {
			log_page(fd);
			close(fd);
			return;
		}
		if(endsWith(doc_path, "stats") || endsWith(doc_path,"stats/")) {
			stats_page(fd);
			close(fd);
			return;
		}
		char *cwd =(char*) malloc(sizeof(char) * 256);
		cwd[0] = '\0';
		cwd = getcwd(NULL, 256);
//		printf("%s\n", cwd);


		if(strcmp(doc_path,"/") == 0)  // the root
			strcat(cwd, "/http-root-dir/htdocs/index.html");
		else {
			if(strncmp(doc_path, "/icons", 6) == 0 || strncmp(doc_path, "/htdocs", 7) == 0 || strstr(doc_path, "cgi-bin" )!=NULL ) // icons or htdocs or cgi
				strcat(cwd, "/http-root-dir/");
			else
				strcat(cwd, "/http-root-dir/htdocs/");
			strcat(cwd, doc_path);
		}
//		printf("cwd:%s\n",cwd);

		if(strstr(doc_path,"/cgi-bin/")!=NULL) { // a cgi program.
			char *prog_name = strstr(doc_path,"-bin/");
			prog_name += 5; // get the file name

			char *exc_pos = strstr(doc_path, "?");
			char *arguments[8]; // can have up to 8 args.
			if(exc_pos == NULL)
				arguments[0] = strdup(prog_name);
			else {
				*exc_pos = '\0';
				arguments[0] = strdup(prog_name);
				*strstr(cwd, "?") = '\0';
			}
			printf("name:%s\n",arguments[0]);
			char *fullpath = strdup(cwd);//("/home/owen/cs252/lab5-src/http-root-dir/cgi-bin/test-env");
			write(fd, cgi_prot, strlen(cgi_prot));	
			char *query_string;
			if(exc_pos == NULL) {
				query_string = "";
			}
			else {
				query_string = strdup(exc_pos+1);
			}
			if(endsWith(prog_name, ".so")) { // modu
				for(int i = 0; i < mod_count; i++) { // if loaded before just exit.
					if(strcmp(prog_name, loaded_mod[i]) == 0) {
						time(&end_time);
						if(difftime(end_time, start_time) > max_time)
							max_time = difftime(end_time, start_time);
						if(difftime(end_time, start_time) < min_time)
							min_time = difftime(end_time, start_time);
						close(fd);
						return;
					}
				}
				loaded_mod[mod_count] = strdup(prog_name); // not loaded.
				mod_count++;
				printf("%s\n%s\n", fullpath, query_string);
				
				void* handle = dlopen(fullpath, RTLD_LAZY);
				typedef void (*func)(int, char *);

				func myhttprun = (func)dlsym(handle, "httprun");
				myhttprun(fd, query_string);

				close(fd);
				time(&end_time);
				if(difftime(end_time, start_time) > max_time)
					max_time = difftime(end_time, start_time);
				if(difftime(end_time, start_time) < min_time)
					min_time = difftime(end_time, start_time);
				return;

			}
			int count = 1;
			char *arg_pos = query_string;
			printf("query_string:%s\n", query_string);
			if(strstr(arg_pos, "+")!=NULL) {
				while(strstr(arg_pos, "+")!=NULL) {
					arguments[count] = (char*) malloc(sizeof(char) * 128);
					int arg_length = strstr(arg_pos, "+") - arg_pos;
					strncpy(arguments[count], arg_pos, arg_length);
					arguments[arg_length] = '\0';
					count++;
					arg_pos += arg_length+1;
				}
			}
			else if(strstr(arg_pos, "&")!=NULL) {
				while(strstr(arg_pos, "&")!=NULL) {
					arguments[count] = (char*) malloc(sizeof(char) * 128);
					int arg_length = strstr(arg_pos, "&") - arg_pos;
					strncpy(arguments[count], arg_pos, arg_length);
					arguments[arg_length] = '\0';
					count++;
					arg_pos += arg_length+1;
				}
			}
			arguments[count] = (char*) malloc(sizeof(char) * 128);
			strcpy(arguments[count], arg_pos);
			count++;
/*			exc_pos = '\0';
			exc_pos++;
			strcat(cwd, doc_path);
			argv[0] = cwd;
			
			if(exc_pos!=NULL) {
				query_string = strdup(exc_pos); // QUERY_STRING.
				while(strstr(exc_pos, "+")!=NULL) {
					argv[count] = (char*) malloc(sizeof(char) * 128); // 128 for each entry
					int arg_length = strstr(exc_pos, "+") - exc_pos;
					strncpy(argv[count], exc_pos ,arg_length);
					argv[arg_length] = '\0';
					count++;
					exc_pos += arg_length+1; // to the next index.
				}
				argv[count] = (char*) malloc(sizeof(char) * 128);
				strcpy(argv[count],exc_pos);
				count++;
			}
			argv[count] = NULL; // set the last to NULL.
//			strcat(cwd, doc_path);*/
			for(int i = 0; i < count; i++) {
				 printf("arg[%d]:%s\n", i, arguments[i]);
			}
			arguments[count] = NULL;
			int ret = fork();
			if(ret == 0) { // child process
				setenv("REQUEST_METHOD", "GET", 1);
				setenv("QUERY_STRING", query_string, 1);
//				int default_out = dup(1);
//				close(default_out);
				dup2( fd, 1);
				int err = execvp(fullpath,arguments);
				if(err < 0)
					perror("execvp");
			}
			waitpid(ret,0,0);
			close(fd);
			time(&end_time);
			if(difftime(end_time, start_time) > max_time)
				max_time = difftime(end_time, start_time);
			if(difftime(end_time, start_time) < min_time)
				min_time = difftime(end_time, start_time);
			return;
		}

		int sortName = 0; // 0 no need to sort, 1 sort by ascend, -1 sort by descend
		int sortTime = 0; // same above
		char * tmp = strstr(cwd, "?C=N;O=");
		if(tmp!=NULL) {
			if(strstr(cwd, "?C=N;O=D")) // descend
				sortName = -1;
			else
				sortName = 1; //ascend
			*tmp = '\0';
		}
		tmp = strstr(cwd, "?C=M;O=");
		if(tmp!=NULL) {
			if(strstr(cwd, "?C=M;O=D"))
				sortTime = -1;
			else
				sortTime = 1;
			*tmp = '\0';
		}

		char *contentType; // 0 for default, 1 for html, 2 for gif
		if(endsWith(cwd, ".html") || endsWith(cwd, ".html/")) {
			contentType = "text/html\r\n\r\n";
		}
		else if(endsWith(cwd, ".gif") || endsWith(cwd, ".gif/")) {
			contentType = "image/gif\r\n\r\n";
		}
		else if(endsWith(cwd, ".png") || endsWith(cwd, ".png/"))
			contentType = "image/png\r\n\r\n"; //default
		else if(endsWith(cwd, ".svg") || endsWith(cwd, ".svg/"))
			contentType = "image/svg+xml\r\n\r\n";
		else
			contentType = "text/plain\r\n\r\n";

		printf("\ncwd:%s\n",cwd);



		struct stat s; // check if it's a file or directory
		if( stat(cwd, &s) == 0) {
			if(s.st_mode & S_IFDIR) { // a directory 
				printf("directory!\n");
				contentType = "text/html\r\n\r\n";
				write(fd, protocol, strlen(protocol));
				write(fd, contentType, strlen(contentType));
				write(fd, html_source1, strlen(html_source1));
				write(fd, cwd, strlen(cwd));
				write(fd, html_source2, strlen(html_source2));
				DIR* dir;
				struct dirent *ent;
				dir = opendir(cwd);
				
				std::vector<files> f_vec; // file vector

				while((ent = readdir(dir)) !=NULL) {
					if(strcmp(ent->d_name,".")== 0) // ignore "."
						continue;

					printf("%s\n", ent->d_name);
				
					files f;
					f.file_name = strdup(ent->d_name);
					char *filedir = (char *)malloc(sizeof(char) * (100 + strlen(cwd)));
					strcpy(filedir, cwd);
					if(!endsWith(filedir, "/"))
						strcat(filedir, "/");
					strcat(filedir, ent->d_name);
					printf("%s\n",filedir);
					f.file_dirc = filedir;
					struct stat s1;
					if(stat(filedir, &s1) == 0) {
						f.modify_time = s1.st_mtime; // modified time;
						if(s1.st_mode & S_IFDIR) { // a direct
							f.isDirectory = true;
						}
						else if (s1.st_mode & S_IFREG) { // a file
							f.isDirectory = false;
						}
						f_vec.push_back(f); // pushing it into it.		
					}
					else {
						printf("nothing\n");
					}
				}
				
				//sorting 
				if(sortName == 1) {
					std::sort(f_vec.begin(), f_vec.end(),nameSortAscend );
					write(fd, "D", 1);
				}
				else if(sortName == -1) { 
					std::sort(f_vec.begin(), f_vec.end(),nameSortDescend );
					write(fd, "A", 1);
				}
				else
					write(fd, "A", 1);
				write(fd, html_source3, strlen(html_source3));

				if (sortTime == 1) {
					std::sort(f_vec.begin(), f_vec.end(),timeSortAscend );
					write(fd, "D", 1);
				}
				else if(sortTime == -1) {
					std::sort(f_vec.begin(), f_vec.end(),timeSortDescend );
					write(fd, "A", 1);
				}
				else
					write(fd, "A", 1);
				write(fd, html_source4, strlen(html_source4));

				while(f_vec.size()>0) {
					printf("%s\t%d\n", f_vec.back().file_name, f_vec.back().modify_time);
//					f_vec.pop_back();
					write(fd, "<tr><td valign=\"top\"><img src=",strlen("<tr><td valign=\"top\"><img src="));
					if(f_vec.back().isDirectory) {
						write(fd, "\"/icons/menu.gif\"",strlen("\"/icons/menu.gif\"")); // icon for directory
					}
					else {
						write(fd, "\"/icons/text.gif\"",strlen("\"/icons/text.gif\"")); // for files
					}
					write(fd,"></td><td><a href=\"",strlen("></td><td><a href=\""));
					write(fd, f_vec.back().file_name, strlen(f_vec.back().file_name));
//					write(fd, "/", 1); needsedit
					write(fd, "\">", strlen("\">"));
//					write(fd, "/", 1);
					write(fd, f_vec.back().file_name,strlen(f_vec.back().file_name));
//					write(fd, "/", 1);
					write(fd, "</a> </td><td>&nbsp;</td><td align=\"right\">", strlen("</a> </td><td>&nbsp;</td><td align=\"right\">"));
					char buf[20];
					strftime(buf, sizeof(buf), "%b %d %H:%M",localtime(&f_vec.back().modify_time));
					write(fd, buf, strlen(buf));
					write(fd, "   </td></tr>\n", strlen("   </td></tr>\n"));
					f_vec.pop_back();
//<tr><td valign="top"><img src="/icons/back.gif" alt="[DIR]"></td><td><a href="/homes/cs252/lab5-http-server/lab5-src/">Parent Directory</a> </td><td>&nbsp;</td><td align="right">  - </td><td>&nbsp;</td></tr>
					}
					write(fd, html_source5, strlen(html_source5));


			}
//			else if(s.st_mode & S_IFREG) { // a file
			else {
				printf("file!\n");
				FILE *file;
				file = fopen(cwd, "r");
				int filedisp = fileno(file);
				char ch;
				int count = 0;
				write(fd, protocol, strlen(protocol));
				write(fd, contentType, strlen(contentType));

				while(count = read(filedisp, &ch, sizeof(char))) {
					if(write(fd, &ch, sizeof(char)) != count)
						perror("write");
//					printf("%c",ch);
				}
				fclose(file);
			}/*
			else {
				write(fd, pro_err, strlen(pro_err));
			}*/
		}
		else {
			write(fd, pro_err, strlen(pro_err));
		} // error
		close(fd);
		time(&end_time);
		if(difftime(end_time, start_time) > max_time)
			max_time = difftime(end_time, start_time);
		if(difftime(end_time, start_time) < min_time)
			min_time = difftime(end_time, start_time);
}


void
processTimeRequest( int fd )
{
  // Buffer used to store the name received from the client
  const int MaxName = 1024;
  char name[ MaxName + 1 ];
  int nameLength = 0;
  int n;

  // Send prompt
  const char * prompt = "\nType your name:";
  write( fd, prompt, strlen( prompt ) );

  // Currently character read
  unsigned char newChar;

  // Last character read
  unsigned char lastChar = 0;

  //
  // The client should send <name><cr><lf>
  // Read the name of the client character by character until a
  // <CR><LF> is found.
  //
    
  while ( nameLength < MaxName &&
	  ( n = read( fd, &newChar, sizeof(newChar) ) ) > 0 ) {

    if ( lastChar == '\015' && newChar == '\012' ) {
      // Discard previous <CR> from name
      nameLength--;
      break;
    }

    name[ nameLength ] = newChar;
    nameLength++;

    lastChar = newChar;
  }

  // Add null character at the end of the string
  name[ nameLength ] = 0;

  printf( "name=%s\n", name );

  // Get time of day
  time_t now;
  time(&now);
  char	*timeString = ctime(&now);

  // Send name and greetings
  const char * hi = "\nHi ";
  const char * timeIs = " the time is:\n";
  write( fd, hi, strlen( hi ) );
  write( fd, name, strlen( name ) );
  write( fd, timeIs, strlen( timeIs ) );
  
  // Send the time of day 
  write(fd, timeString, strlen(timeString));

  // Send last newline
  const char * newline="\n";
  write(fd, newline, strlen(newline));
  
}
